# Nithin S Portfolio
This is a personal portfolio website built in HTML, CSS, and JS.
Host it on GitHub Pages or Replit for free.
